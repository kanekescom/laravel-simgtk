<?php

return [

    'table_prefix' => 'simgtk_',

    'jenjang_sekolah' => [
        'sd' => 'SD',
        'smp' => 'SMP',
    ],

];
