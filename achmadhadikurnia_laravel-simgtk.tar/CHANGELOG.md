# Changelog

All notable changes to `laravel-simgtk` will be documented in this file.
