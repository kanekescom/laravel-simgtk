<?php

use Kanekescom\Simgtk\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
